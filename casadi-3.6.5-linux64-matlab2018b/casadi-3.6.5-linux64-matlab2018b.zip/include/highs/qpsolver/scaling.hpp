#ifndef __SRC_LIB_SCALING_HPP__
#define __SRC_LIB_SCALING_HPP__

#include "runtime.hpp"

void scale(Runtime& rt);

#endif
