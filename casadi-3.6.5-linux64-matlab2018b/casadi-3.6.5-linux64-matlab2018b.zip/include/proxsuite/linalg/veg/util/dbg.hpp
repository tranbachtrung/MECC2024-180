#ifndef VEG_DBG_HPP_Z7QC9XCHS
#define VEG_DBG_HPP_Z7QC9XCHS

#include "proxsuite/linalg/veg/internal/dbg.hpp"

#endif /* end of include guard VEG_DBG_HPP_Z7QC9XCHS */
